
package systemnotas;

import java.util.ArrayList;

/**
 *
 * @author 57322
 */
public class Materia {
    private String nombre;
    
    public Materia() {
    }

    public Materia(String nombre){
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
  
    
}
